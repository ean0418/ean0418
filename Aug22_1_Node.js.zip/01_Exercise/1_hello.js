console.log('안녕하새우!!!');

// ctrl + ` 
// node 1_hello.js